import cv2
import time
import math
import numpy as np
from utils import logger

# ==============================================================================
# [1] CONFIGURATION & CALIBRATION (รวมจากโค้ดที่คุณส่งมา)
# ==============================================================================

# --- 1.1 Dynamic Pixel-to-MM Calibration ---
PIXEL_DISTANCES = [0, 150, 280] 
FACTORS_X       = [0.52, 0.460, 0.410] 
FACTOR_Y_CONST  = 0.4821 

# --- 1.2 Tray Grid Configuration ---
TRAY_ROWS = 3                                                                    
TRAY_COLS = 5                                                                    
START_X_POS = 53.0  # Top-Left Slot X                                                                   
START_Y_POS = 155.0 # Top-Left Slot Y                                                                  
PITCH_X = -27.0     # ระยะห่าง X
PITCH_Y = -27.0     # ระยะห่าง Y

# Generate Tray Matrix
TRAY_MATRIX = []
for r in range(TRAY_ROWS):
    for c in range(TRAY_COLS):
        slot_x = START_X_POS + (c * PITCH_X)
        slot_y = START_Y_POS + (r * PITCH_Y)
        TRAY_MATRIX.append({"id": f"R{r}-C{c}", "x": slot_x, "y": slot_y})

# --- 1.3 Safety Limits ---
LIMIT_X_MIN = -55.0; LIMIT_X_MAX = 53.0                                             
LIMIT_Y_MIN = 101.0; LIMIT_Y_MAX = 155.0                                                 

# --- 1.4 Mechanical Offsets ---
y_fix = 30 
X_ROBOT_OFFSET = 0                                           
Y_ROBOT_OFFSET = 128 - y_fix                                                                                                                                                                                                       

# --- 1.5 Pick Zone Configuration (เส้นเอียง) ---
PICK_ZONE_TOP_RATIO = 0.35    # จุดเริ่มเส้นด้านบน (0.0 - 1.0)
PICK_ZONE_BOTTOM_RATIO = 0.50 # จุดจบเส้นด้านล่าง


# ==============================================================================
# [2] CALCULATION LOGIC
# ==============================================================================

def snap_to_tray_grid(robot_x, robot_y):
    """ดึงพิกัดเข้าหาหลุมที่ใกล้ที่สุด (Tray Snapping)"""
    closest_slot = None
    min_dist = float('inf')
    
    for slot in TRAY_MATRIX:
        dist = math.sqrt((robot_x - slot["x"])**2 + (robot_y - slot["y"])**2)
        if dist < min_dist:
            min_dist = dist
            closest_slot = slot

    if closest_slot:
        # ถ้าใกล้หลุมมากกว่า 20mm ให้ Snap เข้าหลุมเลย
        if min_dist < 20.0:
            logger.info(f"SNAP! [{closest_slot['id']}] -> Fixed({closest_slot['x']:.1f}, {closest_slot['y']:.1f})")
            return closest_slot["x"], closest_slot["y"]
        else:
            logger.info(f"Raw Position (No Snap): {robot_x:.1f}, {robot_y:.1f}")
    
    return robot_x, robot_y 

def object_position_cal(frame, cx, cy):
    """แปลง Pixel เป็น mm (พร้อม Dynamic Factor ใช้ np.interp)"""
    h, w, _ = frame.shape
    cam_center = (int(w / 2), int(h / 2))
    
    offset_x_pixel = cx - cam_center[0]
    offset_y_pixel = cy - cam_center[1]
    
    dist_from_center_x = abs(offset_x_pixel)
    # ใช้ค่า Calibration แบบ Dynamic
    current_factor_x = np.interp(dist_from_center_x, PIXEL_DISTANCES, FACTORS_X)
    
    real_x_mm = offset_x_pixel * current_factor_x
    real_y_mm = offset_y_pixel * FACTOR_Y_CONST 

    # วาดจุด Center
    cv2.circle(frame, (cx, cy), 5, (0, 255, 0), -1)
    cv2.line(frame, cam_center, (cx, cy), (255, 255, 255), 1)
    
    return real_x_mm, real_y_mm

def object_position_check(data_stream, stamp_choose, target_count=10):
    """เช็คความนิ่ง + คำนวณพิกัด + Snap + Safety Limit"""
    if len(data_stream) < target_count: return None
    
    recent_data = data_stream[-target_count:]
    xs = [d[0] for d in recent_data]
    ys = [d[1] for d in recent_data]
    
    # เช็คว่าค่านิ่งพอไหม (แกว่งไม่เกิน 3mm)
    if (max(xs) - min(xs) < 3.0) and (max(ys) - min(ys) < 3.0): 
        avg_x_cam = sum(xs) / len(xs)
        avg_y_cam = sum(ys) / len(ys)
        
        # 1. แปลงเป็นพิกัด Robot
        estimated_robot_x = avg_x_cam + X_ROBOT_OFFSET
        estimated_robot_y = avg_y_cam + Y_ROBOT_OFFSET
        
        # 2. Snap เข้าหลุม
        final_x, final_y = snap_to_tray_grid(estimated_robot_x, estimated_robot_y)
        
        # 3. Safety Limit
        clamped_x = max(LIMIT_X_MIN, min(final_x, LIMIT_X_MAX))
        clamped_y = max(LIMIT_Y_MIN, min(final_y, LIMIT_Y_MAX))
        
        # คืนค่าเป็น G-Code String
        return f"G{stamp_choose} X{clamped_x:.1f} Y{clamped_y:.1f}"
    
    return None 

# ==============================================================================
# [3] VISION LOGIC
# ==============================================================================

def color_detection_choose(c_choose, frame):
    """สร้าง Mask สี (เติมค่า HSV ที่ขาดหายให้แล้ว)"""
    frame_hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    kernel = np.ones((5,5), np.uint8)
    mask = None
    
    # Map Input ให้รองรับตัวพิมพ์เล็ก/ใหญ่/ย่อ
    c = c_choose.lower()

    if c in ["red", "r"]:
        mask = cv2.inRange(frame_hsv, np.array([0, 100, 100]), np.array([10, 255, 255])) + \
               cv2.inRange(frame_hsv, np.array([160, 100, 100]), np.array([179, 255, 255]))
               
    elif c in ["blue", "b"]:
       # [Filled] ค่าสีน้ำเงินมาตรฐาน
       mask = cv2.inRange(frame_hsv, np.array([95, 67, 0]), np.array([149, 255, 255]))
       
    elif c in ["green", "g"]:
       mask = cv2.inRange(frame_hsv, np.array([36, 50, 50]), np.array([89, 255, 255]))
       
    elif c in ["orange", "o"]:
       # [Filled] ค่าสีส้มมาตรฐาน
       mask = cv2.inRange(frame_hsv, np.array([10, 100, 20]), np.array([25, 255, 255]))
       
    elif c in ["yellow", "y"]: 
       # [Filled] ค่าสีเหลืองมาตรฐาน
       mask = cv2.inRange(frame_hsv, np.array([20, 100, 100]), np.array([30, 255, 255]))
    
    if mask is not None:
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    return mask

def camera_shape_detection(c_choose: str, device_num: int):
    """
    ฟังก์ชันหลักที่ Main.py เรียกใช้
    """
    cap = cv2.VideoCapture(device_num)
    cap.set(3, 640)
    cap.set(4, 480)
    
    # Warmup
    for _ in range(5): cap.read()

    data_list = []
    font = cv2.FONT_HERSHEY_SIMPLEX
    start_time = time.time()
    timeout = 30 # วินาที

    logger.info(f"Start Scanning for: {c_choose}")

    try:
        while True:
            ret, frame = cap.read()
            if not ret: break
            
            h, w, _ = frame.shape

            # --- [DRAW PICK ZONE] วาดเส้น Pick Zone บนหน้าจอ ---
            line_x_top = int(w * PICK_ZONE_TOP_RATIO)
            line_x_bot = int(w * PICK_ZONE_BOTTOM_RATIO)
            cv2.line(frame, (line_x_top, 0), (line_x_bot, h), (0, 255, 255), 2)
            cv2.putText(frame, "PICK ZONE -->", (line_x_top + 10, 30), font, 0.6, (0, 255, 255), 2)

            # ค้นหาสี
            mask_c = color_detection_choose(c_choose, frame)
            
            if mask_c is not None:
                contours, _ = cv2.findContours(mask_c, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                valid_cnts = []

                # --- กรองวัตถุที่อยู่ใน Pick Zone เท่านั้น ---
                for cnt in contours:
                    if cv2.contourArea(cnt) > 500:
                        M = cv2.moments(cnt)
                        if M["m00"] > 0:
                            cx = int(M["m10"] / M["m00"])
                            cy = int(M["m01"] / M["m00"])
                            
                            # คำนวณขอบเขตเส้น ณ ความสูง cy
                            threshold_x_at_cy = int(line_x_top + (line_x_bot - line_x_top) * (cy / h))
                            
                            # ถ้าวัตถุอยู่ขวามือของเส้น -> ถือว่าผ่าน
                            if cx > threshold_x_at_cy:
                                valid_cnts.append(cnt)

                if valid_cnts:
                    c = max(valid_cnts, key=cv2.contourArea)
                    x, y, w_rect, h_rect = cv2.boundingRect(c)
                    cv2.rectangle(frame, (x,y), (x+w_rect, y+h_rect), (0,255,0), 2)

                    M = cv2.moments(c)
                    if M["m00"] != 0:
                        cx = int(M["m10"] / M["m00"])
                        cy = int(M["m01"] / M["m00"])
                        
                        # คำนวณพิกัด mm
                        raw_x, raw_y = object_position_cal(frame, cx, cy)
                        data_list.append((raw_x, raw_y))
                        if len(data_list) > 20: data_list.pop(0)

                        # เช็คความนิ่ง + Snap Grid
                        # stamp_choose=7 คือรหัส Pickup ของ Arduino คุณ
                        cmd_result = object_position_check(data_list, stamp_choose=7, target_count=10)
                        
                        if cmd_result:
                            # เจอตำแหน่ง!
                            cv2.putText(frame, "LOCKED!", (x, y-10), font, 1, (0, 255, 0), 2)
                            cv2.imshow("OPEN-SHAPE DETECTION", frame)
                            cv2.waitKey(500) # โชว์ภาพยืนยัน
                            
                            # คืนค่า String กลับไปให้ Main.py ส่ง Serial
                            return cmd_result

            # Time Check
            elapsed = time.time() - start_time
            cv2.putText(frame, f"Time: {int(timeout - elapsed)}s", (10, 450), font, 0.7, (0, 0, 255), 2)
            cv2.imshow("OPEN-SHAPE DETECTION", frame)
            
            if elapsed > timeout:
                logger.warning("Timeout: Object not found")
                return None
            
            if cv2.waitKey(1) == ord('q'):
                break

    except Exception as e:
        logger.error(f"Camera Error: {e}")
    finally:
        cap.release()
        cv2.destroyAllWindows()
    
    return None

def camera_preview_display(stop_event, device_num):
    cap = cv2.VideoCapture(device_num)
    cap.set(3, 640); cap.set(4, 480)
    while not stop_event.is_set():
        ret, frame = cap.read()
        if ret:
            cv2.imshow("PREVIEW", frame)
            if cv2.waitKey(1) == ord('q'): break
    cap.release()
    cv2.destroyAllWindows()