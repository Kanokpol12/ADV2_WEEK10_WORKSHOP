# module/serial_module.py
import serial
import time 
from utils import logger

def init_serial(port):
    try:
        return serial.Serial(port=port, baudrate=115200, timeout=1) # timeout=1 กันค้างตลอดกาล
    except serial.SerialException as e:
        logger.error(f"Serial Port Error: {e}")
        return None

def send_state(serial_port, data):
    try:
        if not serial_port or not serial_port.is_open:
            raise serial.SerialException("Port not open")
        # ส่งข้อมูลพร้อม \n (Arduino บางทีต้องการ newline)
        serial_port.write(f"{data}".encode('utf-8')) 
        time.sleep(0.1)
        # logger.info(f"Sent: {data}")
    except serial.SerialException as e:
        logger.error(f"Error sending data: {e}")
        
def receive_state(serial_port):
    # Mapping สิ่งที่ Arduino ส่งมา -> สิ่งที่ Python เข้าใจ
    state_message = {                                     
        "Sethome position" : 'Home Complete',
        "Ready to detect" : 'Ready',
        "Success to pickup": 'Pickup Complete',
        "Success to stamp": 'Stamp Complete'
    }
    
    try:
        while True:
            if serial_port.in_waiting > 0:
                # อ่านข้อมูล
                line = serial_port.readline().decode('utf-8', errors='ignore').strip()
                
                # [สำคัญ] ปริ้นท์ทุกอย่างที่ Arduino พูดออกมาดู
                if line:
                    logger.info(f"[ARDUINO SAYS]: {line}")
                
                # ตรวจสอบว่าตรงกับ Key ไหนไหม
                if line in state_message:
                    return state_message[line]
                
                # เพิ่ม Logic ช่วย: ถ้า Arduino ส่ง "X:..." มา แปลว่ากำลังขยับ ไม่ใช่ Error
                if "X:" in line and "mm" in line:
                    continue # ข้ามไป รอคำสั่ง Success
                    
    except serial.SerialException as e:
        logger.error(f"Serial error: {e}")
    except KeyboardInterrupt:
        logger.warning("Stopped by user.")
    return None