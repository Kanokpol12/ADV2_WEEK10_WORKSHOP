from paho.mqtt import client as mqtt_client
import random
import vars
from utils import (
    timeit_log, 
    logger)

MQTT_CONNECT = {
    "BROKER" : '192.168.131.128',
    "PORT"   : 1883,
    "CLIENT_ID" : f'idt_adv-{random.randint(0,100)}'
}

MQTT_TOPIC = {                          
    "CONTROL_TOPIC" :  'idt/adv/seq',          # edit topic here
    "COLOR_TOPIC" :  'idt/adv/cos'             # edit topic here
}

def connect_mqtt():
    client = mqtt_client.Client(mqtt_client.CallbackAPIVersion.VERSION1, MQTT_CONNECT["CLIENT_ID"])
    client.on_connect = lambda client, userdata, flags, rc: logger.info("CONNECTED TO MQTT BROKER!") if rc ==0 else logger.error("FAILED TO CONNECT")
    client.on_message = on_message 
    client.connect(MQTT_CONNECT["BROKER"], MQTT_CONNECT["PORT"], 120)
    return client

def on_message(client, userdata, msg):
    vars.sub_msg.append(msg.payload.decode('utf-8'))
    logger.info(f"received '{vars.sub_msg[-1]}' from '{msg.topic}'" )
    
def on_publish(result, topic, msg):
    status = result[0]
    if status == 0:
        logger.info(f"Published: '{msg}' to topic '{topic}'")
    else:
        logger.error(f"Failed to send message to topic {topic}")