# main.py
import time
import threading
import vars
from utils import logger, parse_data
from module.mqtt_module import connect_mqtt, MQTT_TOPIC
from module.camera_module import camera_shape_detection
from module.serial_module import init_serial, send_state, receive_state

# =========================================================
# ตั้งค่า Port ของ Arduino ตรงนี้ (แก้ให้ตรงกับเครื่องจริง)
# - Raspberry Pi: "/dev/ttyUSB0" หรือ "/dev/ttyACM0"
# - Windows: "COM5" 
# =========================================================
ARDUINO_PORT = "COM5" 

def adv_control(client, device_num=1, cart_port=ARDUINO_PORT):
    ser_cart = None
    
    try:
        # --- 1. เชื่อมต่อ Arduino ---
        logger.info(f"Connecting to Cartesian Robot at {cart_port}...")
        ser_cart = init_serial(port=cart_port)
        
        if ser_cart and ser_cart.is_open:
            logger.info("SERIAL OPENED. Waiting 3s for Arduino to boot...")
            time.sleep(3) # [สำคัญ] รอ Arduino Reset ตัวเองหลังเสียบสาย
            
            ser_cart.reset_input_buffer() # เคลียร์ขยะในสาย
            
            # --- 2. Setup Robot (Home) ---
            logger.info("Sending Command: 'home'")
            send_state(serial_port=ser_cart, data="home")
            
            # รอจนกว่าจะ Sethome เสร็จ
            res = receive_state(serial_port=ser_cart)
            logger.info(f"Robot Setup Status: {res}")
            
            time.sleep(1)
            send_state(serial_port=ser_cart, data="ready")
            receive_state(serial_port=ser_cart)
            
            logger.info("SYSTEM READY: Waiting for MQTT Command...")
        else:
            logger.error("Failed to open Serial Port!")
            return

        # --- 3. Main Loop รอคำสั่ง ---
        while True:
            # ตรวจสอบว่ามีข้อความ MQTT เข้ามาไหม
            if len(vars.sub_msg) > 0:
                mqtt_raw = vars.sub_msg.pop(0) # ดึงข้อความออกมาแล้วลบออกจากคิว
                logger.info(f"Processing MQTT: {mqtt_raw}")

                if "Detect" in mqtt_raw:
                    # แปลง "Detect red" -> "red"
                    target_color = parse_data(mqtt_raw)
                    logger.info(f"Target Color: {target_color}")

                    # เรียกกล้องหาตำแหน่ง (จะได้ค่าเช่น "G7 X100.5 Y50.0")
                    gcode_command = camera_shape_detection(c_choose=target_color, device_num=device_num)
                    
                    if gcode_command:
                        logger.info(f"Sending G-Code to Robot: {gcode_command}")
                        
                        # ส่ง G-Code ไป Arduino
                        send_state(serial_port=ser_cart, data=gcode_command)
                        
                        # รอ Robot ทำงานจนเสร็จ (Arduino จะส่ง Success กลับมา)
                        robot_response = receive_state(serial_port=ser_cart)
                        logger.info(f"Job Finished: {robot_response}")
                        
                        # ส่งกลับ MQTT ว่าเสร็จแล้ว (Option)
                        client.publish(MQTT_TOPIC["CONTROL_TOPIC"], f"Done {target_color}")
                    else:
                        logger.warning("Object not found or Camera timed out.")

            time.sleep(0.1) # พัก CPU

    except Exception as e:
        logger.error(f"Main Loop Error: {e}")
    except KeyboardInterrupt:
        logger.warning("Stopped by user.")
    finally:
        if ser_cart: ser_cart.close()
        logger.info("Serial Closed.")

def run():
    # เชื่อมต่อ MQTT
    client = connect_mqtt()
    # Subscribe หัวข้อที่กำหนดใน mqtt_module
    client.subscribe(MQTT_TOPIC["COLOR_TOPIC"]) 
    client.loop_start()
    
    # รันฟังก์ชันหลัก
    adv_control(client=client, cart_port=ARDUINO_PORT)

if __name__ == '__main__':
    run()