#include <Arduino.h>
#include "motor_control.h"
#include "path_functions.h"
#include "websocket.h"

void setup()
{
    Serial.begin(115200);
    motorSetup(10000, 2500);
    // homePosition();

}

void loop()
{
    reciveMessageSerial();
}
