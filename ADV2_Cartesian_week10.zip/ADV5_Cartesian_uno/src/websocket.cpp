#include "motor_control.h"
#include "path_functions.h"
#include "websocket.h"

#include <Arduino.h>
#include <stdint.h>

int DEFAULT_FEEDRATE = 1000;
int DEFAULT_GCODE = 0;
float DEFAULT_X = 0;
float DEFAULT_Y = 0;
float DEFAULT_Z = 0;

int gValue = DEFAULT_GCODE;
int fValue = DEFAULT_FEEDRATE;
float xValue = DEFAULT_X;
float yValue = DEFAULT_Y;
float zValue = DEFAULT_Z;
float redzoneXmin = 140;
float redzoneXmax = 160;
float redzoneYmin = 100;
float redzoneYmax = 160;
float redzoneZmin = 140;
float redzoneZmax = 150;


// ฟังก์ชันสำหรับประมวลผลคำสั่ง G
void handleGCommand(int g, float x, float y)
{
    // Serial.print("G Command: G");
    // Serial.println(g);
    // Serial.print("X Command: ");
    // Serial.println(x);
    // Serial.print("Y Command: ");
    // Serial.println(y);

    // เพิ่มการประมวลผลคำสั่ง G ที่นี่
    switch (g)
    {
    case 0:
        xValue = DEFAULT_X;
        yValue = DEFAULT_Y;
        zValue = DEFAULT_Z;
        homePosition();
        break;
    case 1:
        // G1: Pickup first stamper
        xValue = 105.00;
        yValue = DEFAULT_Y;
        zValue = DEFAULT_Z;
        pickupStamp1(x, y);
        break;
    case 2:
        // G2: Pickup second stamper
        xValue = 105.00;
        yValue = DEFAULT_Y;
        zValue = DEFAULT_Z;
        pickupStamp2(x, y);
        break;
    case 3:
        // G3: Pickup second stamper
        xValue = 105.00;
        yValue = DEFAULT_Y;
        zValue = DEFAULT_Z;
        pickupStamp3(x, y);
        break;
    case 4:
        // G4: Pickup second stamper
        xValue = 105.00;
        yValue = DEFAULT_Y;
        zValue = DEFAULT_Z;
        pickupStamp4(x, y);
        break;
    case 5:
        // G5: Pickup second stamper
        xValue = 105.00;
        yValue = DEFAULT_Y;
        zValue = DEFAULT_Z;
        pickupStamp5(x, y);
        break;
    case 6:
        // G6: Pickup second stamper
        xValue = 105.00;
        yValue = DEFAULT_Y;
        zValue = DEFAULT_Z;
        pickupStamp6(x, y);
        break;
    case 7:
        pickupObject(x, y); 
        break;
    default:
        break;
    }
}

// ฟังก์ชันสำหรับประมวลผลคำสั่ง X, Y, Z
void handleXYZCommand(float x, float y, float z)
{
    // Serial.print("X: ");
    // Serial.print(x);
    // Serial.println(" cm");
    // Serial.print("Y: ");
    // Serial.print(y);
    // Serial.println(" cm");
    // Serial.print("Z: ");
    // Serial.print(z);
    // Serial.println(" cm");

    // เพิ่มการประมวลผลคำสั่ง X, Y, Z ที่นี่
    moveTomm(x, y, z);
}

// ฟังก์ชันสำหรับแยกค่าจากคำสั่ง
float extractValue(String inputString, int startIndex, int endIndex)
{
    String valueStr = inputString.substring(startIndex + 1, endIndex);
    valueStr.trim();
    return valueStr.toFloat();
}

void processGCode(String inputString)
{
    // แยกสตริงตามตัวอักษร G, X, Y, Z
    int indexG = inputString.indexOf('G');
    String valueStr;

    //----------Split G form message and cut GXX form message----------//
    if (indexG != -1)
    {
        // แยกค่า G ออกมา
        String gValueStr = "";
        for (int i = indexG + 1; i < inputString.length(); i++)
        {
            if (isDigit(inputString[i]))
            {
                gValueStr += inputString[i];
            }
            else
            {
                break;
            }
        }
        gValue = gValueStr.toInt();

        // ตัด GXX ออกจากสตริง
        inputString = inputString.substring(indexG + gValueStr.length() + 1);

        // อัพเดตตำแหน่ง indexX, indexY, indexZ ใหม่ตามสตริงที่เหลืออยู่
        int indexX = inputString.indexOf('X');
        int indexY = inputString.indexOf('Y');
        int indexZ = inputString.indexOf('Z');

        // Extract X value if present
        if (indexX != -1)
        {
            xValue = extractValue(inputString, indexX, (indexY != -1) ? indexY : (indexZ != -1) ? indexZ
                                                                                                : inputString.length());
            // Serial.println(xValue);
        }

        // Extract Y value if present
        if (indexY != -1)
        {
            yValue = extractValue(inputString, indexY, (indexZ != -1) ? indexZ : inputString.length());
            // Serial.println(yValue);
        }

        // Extract Z value if present
        if (indexZ != -1)
        {
            zValue = extractValue(inputString, indexZ, inputString.length());
            // Serial.println(zValue);
        }

        handleGCommand(gValue, xValue, yValue);
    }
    else
    {
        // กรณีที่ไม่มี G: แยกค่าจาก X, Y, Z โดยตรง
        int indexX = inputString.indexOf('X');
        int indexY = inputString.indexOf('Y');
        int indexZ = inputString.indexOf('Z');

        if (indexX != -1)
        {
            xValue = extractValue(inputString, indexX, (indexY != -1) ? indexY : (indexZ != -1) ? indexZ
                                                                                                : inputString.length());
            // Serial.println(xValue);
        }

        if (indexY != -1)
        {
            yValue = extractValue(inputString, indexY, (indexZ != -1) ? indexZ : inputString.length());
            // Serial.println(yValue);
        }

        if (indexZ != -1)
        {
            zValue = extractValue(inputString, indexZ, inputString.length());
            // Serial.println(zValue);
        }

        handleXYZCommand(xValue, yValue, zValue);
    }

    // Command home position
    if (inputString.equalsIgnoreCase("home"))
    {
        xValue = DEFAULT_X;
        yValue = DEFAULT_Y;
        zValue = DEFAULT_Z;
        homePosition();
    }
    else if (inputString.equalsIgnoreCase("pick"))
    {
        xValue = DEFAULT_X;
        yValue = DEFAULT_Y;
        zValue = DEFAULT_Z;
        pickupStamp1(100, 50);
        pickupStamp2(100, 50);
        pickupStamp3(100, 50);
        pickupStamp4(100, 50);
        pickupStamp5(100, 50);
        pickupStamp6(100, 50);
    }
    else if (inputString.equalsIgnoreCase("ready"))
    {
        xValue = 105.00;
        yValue = 25.00;
        zValue = DEFAULT_Z;
        readyToDetect();
    }
    else if (inputString.equalsIgnoreCase("reset"))
    {
        interruptLoop();
        resetBoard();
    }
}

void reciveMessageSerial()
{
    // ตรวจสอบว่ามีข้อมูลที่เข้ามาทาง Serial หรือไม่
    if (Serial.available() > 0)
    {
        // อ่าน String จาก Serial
        String inputString = Serial.readString();
        inputString.trim();

        // แสดง String ที่รับเข้ามา
        Serial.println("Received: " + inputString);

        // Splitmessage
        processGCode(inputString);
    }
}
