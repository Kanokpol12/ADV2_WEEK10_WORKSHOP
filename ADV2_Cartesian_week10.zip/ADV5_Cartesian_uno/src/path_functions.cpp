#include "path_functions.h"
#include "motor_control.h"
#include "websocket.h"

float OBJECT_HEIGHT = 75.00;    // ความสูงObjectที่จะปั้ม
float STAMPER_HEIGHT = 37.00;
float WORKSPACE_Z = 170.00; // Fixed heigh
float GAP_PREPRESS = 2.50;
float PRESS_DISTANCE = 18.00; // ปิดฝา 17 เปิดฝา 18.5
float STAMPER_1_POSY = 181.00;
float STAMPER_2_POSY = 146.50;
float STAMPER_3_POSY = 112.50;
float STAMPER_4_POSY = 79.00;
float STAMPER_5_POSY = 46.50;
float STAMPER_6_POSY = 11.50;

// X5.5 Y9.0 Top Left

// Pump1 X1.7 Y8.25
void TestPathRectangle()
{
  moveTomm(0, 0, 0);
  moveTomm(0, 16, 0);
  moveTomm(20, 16, 0);
  moveTomm(20, 0, 0);
  moveTomm(0, 0, 0);
  moveTomm(20, 16, 0);
  moveTomm(0, 0, 0);
}
// ----------- STAMP_PATH ---------------------//

void pickupStamp1(float objectX, float objectY)
{
  float poszPrestamp = WORKSPACE_Z - STAMPER_HEIGHT - OBJECT_HEIGHT - GAP_PREPRESS;
  float poszStamp = WORKSPACE_Z - STAMPER_HEIGHT - OBJECT_HEIGHT + PRESS_DISTANCE;

  Serial.println("Pick up first stamper");
  moveTomm(130, STAMPER_1_POSY, 0);   // จ่อหน้า
  moveTomm(130, STAMPER_1_POSY, 150); // Z down
  moveTomm(156, STAMPER_1_POSY, 150);  // X forward
  moveTomm(156, STAMPER_1_POSY, 0);    // Z ขึ้น
  moveTomm(130, STAMPER_1_POSY, 0);   // X back
  moveTomm(objectX, objectY, poszPrestamp);   // before stamp
  moveTomm(objectX, objectY, poszStamp);      // stamp
  moveTomm(objectX, objectY, poszPrestamp);   // after stamp
  moveTomm(130, STAMPER_1_POSY, 0);   // จ่อหน้า
  moveTomm(156, STAMPER_1_POSY, 0);    // เข้าช่อง
  moveTomm(156, STAMPER_1_POSY, 150);  // กดลงช่อง
  moveTomm(130, STAMPER_1_POSY, 150); // X back
  moveTomm(130, STAMPER_1_POSY, 0);   // Z up
  Serial.println("Success to stamp");
  readyToDetect(); // end
}

void pickupStamp2(float objectX, float objectY)
{
  float poszPrestamp = WORKSPACE_Z - STAMPER_HEIGHT - OBJECT_HEIGHT - GAP_PREPRESS;
  float poszStamp = WORKSPACE_Z - STAMPER_HEIGHT - OBJECT_HEIGHT + PRESS_DISTANCE;

  Serial.println("Pick up first stamper");
  moveTomm(130, STAMPER_2_POSY, 0);   // จ่อหน้า
  moveTomm(130, STAMPER_2_POSY, 150); // Z down
  moveTomm(156, STAMPER_2_POSY, 150);  // X forward
  moveTomm(156, STAMPER_2_POSY, 0);    // Z ขึ้น
  moveTomm(130, STAMPER_2_POSY, 0);   // X back
  moveTomm(objectX, objectY, poszPrestamp);   // before stamp
  moveTomm(objectX, objectY, poszStamp);      // stamp
  moveTomm(objectX, objectY, poszPrestamp);   // after stamp
  moveTomm(130, STAMPER_2_POSY, 0);   // จ่อหน้า
  moveTomm(156, STAMPER_2_POSY, 0);    // เข้าช่อง
  moveTomm(156, STAMPER_2_POSY, 150);  // กดลงช่อง
  moveTomm(130, STAMPER_2_POSY, 150); // X back
  moveTomm(130, STAMPER_2_POSY, 0);   // Z up
  Serial.println("Success to stamp");
  readyToDetect(); // end
}

void pickupStamp3(float objectX, float objectY)
{
  float poszPrestamp = WORKSPACE_Z - STAMPER_HEIGHT - OBJECT_HEIGHT - GAP_PREPRESS;
  float poszStamp = WORKSPACE_Z - STAMPER_HEIGHT - OBJECT_HEIGHT + PRESS_DISTANCE;

  Serial.println("Pick up first stamper");
  moveTomm(130, STAMPER_3_POSY, 0);   // จ่อหน้า
  moveTomm(130, STAMPER_3_POSY, 150); // Z down
  moveTomm(156, STAMPER_3_POSY, 150);  // X forward
  moveTomm(156, STAMPER_3_POSY, 0);    // Z ขึ้น
  moveTomm(130, STAMPER_3_POSY, 0);   // X back
  moveTomm(objectX, objectY, poszPrestamp);   // before stamp
  moveTomm(objectX, objectY, poszStamp);      // stamp
  moveTomm(objectX, objectY, poszPrestamp);   // after stamp
  moveTomm(130, STAMPER_3_POSY, 0);   // จ่อหน้า
  moveTomm(156, STAMPER_3_POSY, 0);    // เข้าช่อง
  moveTomm(156, STAMPER_3_POSY, 150);  // กดลงช่อง
  moveTomm(130, STAMPER_3_POSY, 150); // X back
  moveTomm(130, STAMPER_3_POSY, 0);   // Z up
  Serial.println("Success to stamp");
  readyToDetect(); // end
}

void pickupStamp4(float objectX, float objectY)
{
  float poszPrestamp = WORKSPACE_Z - STAMPER_HEIGHT - OBJECT_HEIGHT - GAP_PREPRESS;
  float poszStamp = WORKSPACE_Z - STAMPER_HEIGHT - OBJECT_HEIGHT + PRESS_DISTANCE;

  Serial.println("Pick up first stamper");
  moveTomm(130, STAMPER_4_POSY, 0);   // จ่อหน้า
  moveTomm(130, STAMPER_4_POSY, 150); // Z down
  moveTomm(156, STAMPER_4_POSY, 150);  // X forward
  moveTomm(156, STAMPER_4_POSY, 0);    // Z ขึ้น
  moveTomm(130, STAMPER_4_POSY, 0);   // X back
  moveTomm(objectX, objectY, poszPrestamp);   // before stamp
  moveTomm(objectX, objectY, poszStamp);      // stamp
  moveTomm(objectX, objectY, poszPrestamp);   // after stamp
  moveTomm(130, STAMPER_4_POSY, 0);   // จ่อหน้า
  moveTomm(156, STAMPER_4_POSY, 0);    // เข้าช่อง
  moveTomm(156, STAMPER_4_POSY, 150);  // กดลงช่อง
  moveTomm(130, STAMPER_4_POSY, 150); // X back
  moveTomm(130, STAMPER_4_POSY, 0);   // Z up
  Serial.println("Success to stamp");
  readyToDetect(); // end
}

void pickupStamp5(float objectX, float objectY)
{
  float poszPrestamp = WORKSPACE_Z - STAMPER_HEIGHT - OBJECT_HEIGHT - GAP_PREPRESS;
  float poszStamp = WORKSPACE_Z - STAMPER_HEIGHT - OBJECT_HEIGHT + PRESS_DISTANCE;

  Serial.println("Pick up first stamper");
  moveTomm(130, STAMPER_5_POSY, 0);   // จ่อหน้า
  moveTomm(130, STAMPER_5_POSY, 150); // Z down
  moveTomm(156, STAMPER_5_POSY, 150);  // X forward
  moveTomm(156, STAMPER_5_POSY, 0);    // Z ขึ้น
  moveTomm(130, STAMPER_5_POSY, 0);   // X back
  moveTomm(objectX, objectY, poszPrestamp);   // before stamp
  moveTomm(objectX, objectY, poszStamp);      // stamp
  moveTomm(objectX, objectY, poszPrestamp);   // after stamp
  moveTomm(130, STAMPER_5_POSY, 0);   // จ่อหน้า
  moveTomm(156, STAMPER_5_POSY, 0);    // เข้าช่อง
  moveTomm(156, STAMPER_5_POSY, 150);  // กดลงช่อง
  moveTomm(130, STAMPER_5_POSY, 150); // X back
  moveTomm(130, STAMPER_5_POSY, 0);   // Z up
  Serial.println("Success to stamp");
  readyToDetect(); // end
}

void pickupStamp6(float objectX, float objectY)
{
  float poszPrestamp = WORKSPACE_Z - STAMPER_HEIGHT - OBJECT_HEIGHT - GAP_PREPRESS;
  float poszStamp = WORKSPACE_Z - STAMPER_HEIGHT - OBJECT_HEIGHT + PRESS_DISTANCE;

  Serial.println("Pick up first stamper");
  moveTomm(130, STAMPER_6_POSY, 0);   // จ่อหน้า
  moveTomm(130, STAMPER_6_POSY, 150); // Z down
  moveTomm(156, STAMPER_6_POSY, 150);  // X forward
  moveTomm(156, STAMPER_6_POSY, 0);    // Z ขึ้น
  moveTomm(130, STAMPER_6_POSY, 0);   // X back
  moveTomm(objectX, objectY, poszPrestamp);   // before stamp
  moveTomm(objectX, objectY, poszStamp);      // stamp
  moveTomm(objectX, objectY, poszPrestamp);   // after stamp
  moveTomm(130, STAMPER_6_POSY, 0);   // จ่อหน้า
  moveTomm(156, STAMPER_6_POSY, 0);    // เข้าช่อง
  moveTomm(156, STAMPER_6_POSY, 150);  // กดลงช่อง
  moveTomm(130, STAMPER_6_POSY, 150); // X back
  moveTomm(130, STAMPER_6_POSY, 0);   // Z up
  Serial.println("Success to stamp");
  readyToDetect(); // end
}

void pickupObject(float objectX, float objectY)
{
  moveTomm(0, 0, 0);
  Serial.println("Start Pick up Object");
  Serial.print("Moving to X:");
  Serial.print(objectX);
  Serial.print(" Y:");
  Serial.println(objectY);
  Gripped(160);
  moveTomm(objectX, objectY, 0);
  Rotate(9);
  delay(1000);
  moveTomm(objectX, objectY, 112);
  Gripped(25);
  moveTomm(objectX, objectY, 0);
  delay(2000);
  moveTomm(objectX, objectY, 108);
  Gripped(160);
  delay(1000);
  moveTomm(objectX, objectY, 0);
  Serial.println("Success to pickup");
  homePosition();
}

// ----------- PICKUP_PATH ---------------------//

void readyToDetect()
{
  Rotate(9);
  delay(1000);
  Gripped(150);
  delay(1000);
  moveTomm(0, 0, 0);
  Serial.println("Ready to detect");
}
