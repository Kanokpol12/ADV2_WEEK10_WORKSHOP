#ifndef PATH_FUNCTIONS_H
#define PATH_FUNCTIONS_H


void TestPathRectangle();

void pickupStamp1(float objectX, float objectY);

void pickupStamp2(float objectX, float objectY);

void pickupStamp3(float objectX, float objectY);

void pickupStamp4(float objectX, float objectY);

void pickupStamp5(float objectX, float objectY);

void pickupStamp6(float objectX, float objectY);

void pickupObject(float objectX, float objectY);

void readyToDetect();

#endif
