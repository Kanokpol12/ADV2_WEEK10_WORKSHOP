#ifndef WEBSOCKET_H
#define WEBSOCKET_H

// #include <WebSocketServer.h>

void reciveMessageSerial();

void processGCode(String inputString);

void handleGCommand(int g, float x, float y);

void handleXYZCommand(float x, float y, float z);

#endif
