#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H

#include <AccelStepper.h>

void motorSetup(uint16_t maxSpeed, uint16_t maxAccel);

void homePosition();

void moveTomm(float targetX, float targetY, float targetZ);

void Gripped(float pos);

void Rotate (float pos);

void interruptLoop();

void resetBoard();

 

#endif
